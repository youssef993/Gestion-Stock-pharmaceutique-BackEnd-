package com.sante.gsp.services;

import java.util.List;

import com.sante.gsp.entities.Account;
import com.sante.gsp.model.MessageResponse;

public interface AccountService {

	public MessageResponse save(Account cmpte);
	public MessageResponse update(Account cmpte);
	public MessageResponse delete(Integer id);
	public List<Account> findAll();
	
}
