package com.sante.gsp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sante.gsp.entities.Medicament;

public interface MedicamentRepository extends JpaRepository<Medicament, Integer>{

}
