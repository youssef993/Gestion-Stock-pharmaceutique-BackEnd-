package com.sante.gsp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sante.gsp.entities.Pharmacie;

public interface PharmacieRepository extends JpaRepository<Pharmacie, Integer> {

	boolean existsByNomPh(String nomPh);
	boolean existsByMedicamentAndNomPh(String medicament, String nomPh);
	boolean existsByMedicamentAndId(String medicament, Integer id);
	List<Pharmacie> findByNomPh(String nomPh);
	List<Pharmacie> findByMedicament(String medicament);
	Pharmacie findByNomPhAndMedicament(String nomPh, String medicament);
}
