package com.sante.gsp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sante.gsp.entities.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {
	boolean existsByUsername(String username);
	boolean existsByUsernameAndId(String username, Integer id);
	boolean existsById(Integer id);
}
