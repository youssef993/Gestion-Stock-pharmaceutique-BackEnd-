package com.sante.gsp.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sante.gsp.entities.Account;
import com.sante.gsp.model.MessageResponse;
import com.sante.gsp.repositories.AccountRepository;
import com.sante.gsp.services.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository cmptRepository;
	
	@Override
	public MessageResponse save(Account cmpte) {
		boolean exist= cmptRepository.existsByUsername(cmpte.getUsername());
		if(exist) {
			return new MessageResponse(false, "USERNAME EXISTENT!!!!");
		}
		cmptRepository.save(cmpte);
		return new MessageResponse(true, "Ajout Effectué avec success");
	}

	@Override
	public MessageResponse update(Account cmpte) {
		boolean exist = cmptRepository.existsByUsernameAndId(cmpte.getUsername(), cmpte.getId());
		if (!exist) {
			exist = cmptRepository.existsByUsername(cmpte.getUsername());
			if (exist) {
				return new MessageResponse(false, "USERNAME EXISTENT");
			}
		}
		cmptRepository.save(cmpte);
		return new MessageResponse(true, "modification effectué avec succés");
	}

	@Override
	public MessageResponse delete(Integer id) {
		boolean exist = cmptRepository.existsById(id);
		if (!exist) {
			return new MessageResponse(false, "user not found");
		}
		cmptRepository.deleteById(id);
		return new MessageResponse(true, "Suppression effectué avec succés");
	}

	@Override
	public List<Account> findAll() {
		return cmptRepository.findAll();
	}

}
