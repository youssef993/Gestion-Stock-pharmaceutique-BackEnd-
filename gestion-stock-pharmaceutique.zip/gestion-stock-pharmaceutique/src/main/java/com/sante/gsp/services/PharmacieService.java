package com.sante.gsp.services;

import java.util.List;

import com.sante.gsp.entities.Pharmacie;
import com.sante.gsp.model.MessageResponse;




public interface PharmacieService {

	public MessageResponse save(Pharmacie pharmacie);
	public MessageResponse update(Pharmacie pharmacie);
	public MessageResponse delete(Integer id);
	public List<Pharmacie> findAll();
	public List<Pharmacie> findByNomPh(String nomPh);
	public List<Pharmacie> findByMedicament(String medicament);
	public Pharmacie findByNomPhAndMedicament(String nomPh, String medicament); 
}
