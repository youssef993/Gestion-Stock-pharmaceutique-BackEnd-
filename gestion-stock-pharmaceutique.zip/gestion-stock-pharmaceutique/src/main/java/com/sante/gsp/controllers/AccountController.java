package com.sante.gsp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sante.gsp.entities.Account;
import com.sante.gsp.model.MessageResponse;
import com.sante.gsp.services.AccountService;

@RestController
@CrossOrigin("*")
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountService cmptService;
	@GetMapping
	public List<Account> getAll(){
		return cmptService.findAll();
	}
	@PutMapping
	public MessageResponse edit(@RequestBody Account cmpt) {
		return cmptService.update(cmpt);
	}
	@PostMapping
	public MessageResponse add(@RequestBody Account cmpt) {
		return cmptService.save(cmpt);
	}
	@DeleteMapping("/{id}")
	public MessageResponse Delete(@PathVariable Integer id) {
		return cmptService.delete(id);
	}

}
