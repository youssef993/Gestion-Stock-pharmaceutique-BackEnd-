package com.sante.gsp.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sante.gsp.entities.Pharmacie;
import com.sante.gsp.model.MessageResponse;
import com.sante.gsp.repositories.PharmacieRepository;
import com.sante.gsp.services.PharmacieService;

@Service
public class PharmacieServiceImpl implements PharmacieService {
	@Autowired
	private PharmacieRepository pharmacieRepository;

	@Transactional
	@Override
	public MessageResponse save(Pharmacie pharmacie) {
		boolean exist= pharmacieRepository.existsByMedicamentAndNomPh(pharmacie.getMedicament(), pharmacie.getNomPh());
		boolean exist1 = pharmacieRepository.existsByNomPh(pharmacie.getNomPh());
		if(exist) {
			
				return new MessageResponse(false, "medicament existent dans votre pharmacie!!!");
			
		}
		pharmacieRepository.save(pharmacie);
		return new MessageResponse(true, "Ajout effectuer avec success");
	}

	@Transactional
	@Override
	public MessageResponse update(Pharmacie pharmacie) {
		boolean exist= pharmacieRepository.existsByMedicamentAndId(pharmacie.getMedicament(), pharmacie.getId());
		boolean exist1 = pharmacieRepository.existsByNomPh(pharmacie.getNomPh());
		if(!exist) {
			
				return new MessageResponse(false, "medicament inexistent dans votre pharmacie!!!");
			
		}
		Integer stock=pharmacie.getStock();
		if(stock.equals(0)) {
			pharmacieRepository.delete(pharmacie);
			return new MessageResponse(true, "medicament supprimer de votre stock!!!");
		}
		pharmacieRepository.save(pharmacie);
		return new MessageResponse(true, "medicament modifier");
	}

	@Transactional
	@Override
	public MessageResponse delete(Integer id) {
		boolean exist= pharmacieRepository.existsById(id);
		if(!exist) {
			return new MessageResponse(false, "Medicament Not Found!!!");
		}
		pharmacieRepository.deleteById(id);
		return new MessageResponse(true, "Medicament supprimer AVEC SUCCES");	}

	@Override
	public List<Pharmacie> findAll() {
		// TODO Auto-generated method stub
		return pharmacieRepository.findAll();
	}

	@Override
	public List<Pharmacie> findByNomPh(String nomPh) {
		// TODO Auto-generated method stub
		return pharmacieRepository.findByNomPh(nomPh);
	}

	@Override
	public List<Pharmacie> findByMedicament(String medicament) {
		// TODO Auto-generated method stub
		return pharmacieRepository.findByMedicament(medicament);
	}

	@Override
	public Pharmacie findByNomPhAndMedicament(String nomPh, String medicament) {
		// TODO Auto-generated method stub
		return pharmacieRepository.findByNomPhAndMedicament(nomPh, medicament);
	};

}
