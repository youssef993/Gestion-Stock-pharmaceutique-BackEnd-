package com.sante.gsp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sante.gsp.entities.Pharmacie;
import com.sante.gsp.model.MessageResponse;
import com.sante.gsp.services.PharmacieService;

@RestController
@CrossOrigin("*")
@RequestMapping("/pharmacie")
public class PharmacieController {
@Autowired
private PharmacieService pharmacieService;
@GetMapping
public List<Pharmacie> getAll(){
	return pharmacieService.findAll();
}
@GetMapping("/{nomPh}")
public List<Pharmacie> getPharmacie(@PathVariable("nomPh") String nomPh){
	return pharmacieService.findByNomPh(nomPh);
}
@GetMapping("/Pharmacie/{medicament}")
public List<Pharmacie> getMed(@PathVariable String medicament){
	return pharmacieService.findByMedicament(medicament);
}
@GetMapping("/{nomPh}/{medicament}")
public Pharmacie getMedicament(@PathVariable("nomPh") String nomPh,@PathVariable("medicament") String medicament ){
	return pharmacieService.findByNomPhAndMedicament(nomPh, medicament);
	}
@PutMapping
public MessageResponse edit(@RequestBody Pharmacie pharmacie) {
	return pharmacieService.update(pharmacie);
}
@PostMapping
public MessageResponse add(@RequestBody Pharmacie pharmacie) {
	return pharmacieService.save(pharmacie);
}
@DeleteMapping("/{id}")
public MessageResponse Delete(@PathVariable Integer id) {
	return pharmacieService.delete(id);
}


}
